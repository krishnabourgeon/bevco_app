import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:kiosk/app_colors.dart';
import 'package:kiosk/app_header.dart';
import 'package:kiosk/confirm_dialog.dart';
import 'package:kiosk/empty_bill_state.dart';
import 'package:kiosk/models/dummy_products.dart';
import 'package:kiosk/models/product.dart';
import 'package:kiosk/product_tile.dart';
import 'package:kiosk/responsive.dart';
import 'package:kiosk/view/bill_summary_screen.dart';


class BillScreen extends StatefulWidget {
  const BillScreen({super.key});

  @override
  State<BillScreen> createState() => _BillScreenState();
}

class _BillScreenState extends State<BillScreen> {
  final TextEditingController _barcodeController =
    TextEditingController();

bool _isSearchingBarcode = false;

final StringBuffer _scanBuffer = StringBuffer();
DateTime _lastKeyTime = DateTime.now();
Timer? _scanTimer; // needs: import 'dart:async';

static const _beep = MethodChannel('kerala_beverage_app/beep');

@override
void initState() {
  super.initState();
  HardwareKeyboard.instance.addHandler(_onKey);
}

@override
void dispose() {
  HardwareKeyboard.instance.removeHandler(_onKey);
  _scanTimer?.cancel();
  _barcodeController.dispose();
  super.dispose();
}

bool _onKey(KeyEvent event) {
  if (event is! KeyDownEvent) return false; // ignore key-up / repeat

  final now = DateTime.now();
  // Scanners type very fast (<50 ms per key). A long gap means a new scan
  // (or a human typing), so start over.
  if (now.difference(_lastKeyTime).inMilliseconds > 100) {
    _scanBuffer.clear();
  }
  _lastKeyTime = now;

  final key = event.logicalKey;
  if (key == LogicalKeyboardKey.enter ||
      key == LogicalKeyboardKey.numpadEnter ||
      key == LogicalKeyboardKey.tab) {
    _submitScan();
    return true;
  }

  final ch = event.character;
  if (ch != null && ch.isNotEmpty && ch.codeUnitAt(0) >= 32) {
    _scanBuffer.write(ch);
    // Fallback for scanners configured with no Enter suffix.
    _scanTimer?.cancel();
    _scanTimer = Timer(const Duration(milliseconds: 150), _submitScan);
    return true; // consume so nothing else reacts
  }
  return false;
}

void _submitScan() {
  _scanTimer?.cancel();
  final code = _scanBuffer.toString().trim();
  _scanBuffer.clear();
  if (code.length >= 4) _searchBarcode(code); // ignore stray keypresses
}


Future<void> _searchBarcode(String value) async {
  final barcode = value.trim();
  if (barcode.isEmpty) return;

  debugPrint('scanned: "$barcode"'); // remove after testing

  Product? product;
  for (final item in dummyProducts) {
    if (item.barcode.trim().toLowerCase() == barcode.toLowerCase()) {
      product = item;
      break;
    }
  }

  if (!mounted) return;

  if (product == null) {
    _beep.invokeMethod('error');                 // ADDED
    _snack('Product not found: $barcode');
    return;
  }

  final found = product; // non-null copy, so no `!` is needed below
  final index = _items.indexWhere(
    (item) => item.product.barcode.toLowerCase() == found.barcode.toLowerCase(),
  );

  setState(() {
    if (index >= 0) {
      _items[index] = _items[index].copyWith(qty: _items[index].qty + 1);
    } else {
      _items.add(CartItem(found, qty: 1));
    }
  });

  _beep.invokeMethod('success');                 // ADDED
  _snack('${found.name} added to bill');
}
  // Dummy data for now. Later, fill this list from your backend.
  //late final List<CartItem> _items = kPreviewEmptyState ? [] : [...dummyCart];
  final List<CartItem> _items = [];

  double get _subtotal => _items.fold(0, (s, i) => s + i.lineTotal);
  int get _count => _items.fold(0, (s, i) => s + i.qty);

  void _setQty(int index, int qty) => setState(() => _items[index] = _items[index].copyWith(qty: qty));

  Future<void> _remove(int index) async {
    final ok = await showConfirmDialog(
      context,
      title: 'Remove item?',
      message: '${_items[index].product.name} will be removed from this bill.',
      confirmLabel: 'Remove',
    );
    if (ok && mounted) setState(() => _items.removeAt(index));
  }

  Future<void> _clearAll() async {
    final ok = await showConfirmDialog(
      context,
      title: 'Clear all items?',
      message: 'All products will be removed from this bill.',
      confirmLabel: 'Clear all',
    );
    if (ok && mounted) setState(_items.clear);
  }

  // Future<void> _openPreview() async {
  //   final mode = await Navigator.push<String>(
  //     context,
  //     MaterialPageRoute(builder: (_) => BillPreviewScreen(items: List.of(_items))),
  //   );
  //   if (mode == null || !mounted) return;
  //   // TODO: start the actual payment here ("CARD" or "UPI").
  //   _snack('Paying via $mode — payment integration coming next');
  // }

  void _snack(String msg) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));

  

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: AnnotatedRegion<SystemUiOverlayStyle>(
//         value: SystemUiOverlayStyle.dark,
//         child: Column(
//           children: [
//             const AppHeader(),
//             Expanded(child: _body()),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _body() {
//     return LayoutBuilder(builder: (context, c) {
//       if (_items.isEmpty) return const EmptyBillState();

//       final w = c.maxWidth;
//       final h = c.maxHeight;
//       // Side panel on wide screens, and on phones held in landscape.
//       final split = w >= Responsive.splitBreakpoint || (w >= Responsive.tabletBreakpoint && h < 520);
//       final hPad = w >= Responsive.desktopBreakpoint ? 24.0 : 16.0;

//       final list = _buildList(hPad);

//       if (split) {
//         final panelWidth = (w * 0.34).clamp(340.0, 420.0);
//         return Center(
//           child: ConstrainedBox(
//             constraints: const BoxConstraints(maxWidth: Responsive.maxContentWidth),
//             child: Row(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Expanded(child: list),
//                 SizedBox(
//                   width: panelWidth,
//                   child: SingleChildScrollView(
//                     padding: EdgeInsets.fromLTRB(0, 16, hPad, 16),
//                     child: _summary(isPanel: true),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       }

//       // Phones and tablets in portrait: list on top, bill bar at the bottom.
//       return Center(
//         child: ConstrainedBox(
//           constraints: const BoxConstraints(maxWidth: 720),
//           child: Column(
//             children: [
//               Expanded(child: list),
//               _summary(isPanel: false),
//             ],
//           ),
//         ),
//       );
//     });
//   }

//   Widget _summary({required bool isPanel}) => BillSummary(
//         itemCount: _count,
//         subtotal: _subtotal,
//         isPanel: isPanel,
//         //onPay: _openPreview,
//         onPrint: () => _snack('Print bill coming next'),
//       );

//   Widget _buildList(double hPad) {
//     return Column(
//       children: [
//         Padding(
//           padding: EdgeInsets.fromLTRB(hPad, 14, hPad, 6),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text('Items (${_items.length})',
//                   style: const TextStyle(
//                       fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textDark)),
//               TextButton.icon(
//                 onPressed: _clearAll,
//                 icon: const Icon(Icons.delete_outline, size: 18),
//                 label: const Text('Clear all'),
//                 style: TextButton.styleFrom(foregroundColor: AppColors.primary),
//               ),
//             ],
//           ),
//         ),
//         Expanded(
//           child: ListView.separated(
//             padding: EdgeInsets.fromLTRB(hPad, 6, hPad, 16),
//             itemCount: _items.length,
//             separatorBuilder: (_, __) => const SizedBox(height: 10),
//             itemBuilder: (_, i) => ProductTile(
//               item: _items[i],
//               onQtyChanged: (q) => _setQty(i, q),
//               onRemove: () => _remove(i),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }



Color get _red => const Color(0xFFD32F2F); // same _red as your product screen

@override
Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: Colors.white,
    body: AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Padding(
        padding: EdgeInsets.fromLTRB(90.w, 40.h, 90.w, 5.h),
        child: Column(
          children: [
            Expanded(
              child: Column(
                children: [
                  25.verticalSpace,
                  _buildHeader(),
                  20.verticalSpace,
                  Expanded(child: _buildBillCard()),
                ],
              ),
            ),
            _buildBottomBar(),
          ],
        ),
      ),
    ),
  );
}

// ---------------- HEADER ----------------
Widget _buildHeader() {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 60.w, vertical: 15.h),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(30.r),
      border: Border.all(color: Colors.black),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("BEVCO",
                style: TextStyle(
                  color: _red,
                  fontSize: 50.sp,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 4,
                )),
            Text("Your bill",
                style: TextStyle(color: Colors.black, fontSize: 30.sp)),
          ],
        ),
        SizedBox(
          height: 70.h,
          width: 250.w,
          child: Image.asset(
            "assets/images/bevco_logo.png",
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => const SizedBox(),
          ),
        ),
      ],
    ),
  );
}

// ---------------- BILL CARD ----------------
Widget _buildBillCard() {
  return Container(
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(45.r),
      border: Border.all(color: Colors.black),
    ),
    padding: EdgeInsets.symmetric(horizontal: 60.w, vertical: 20.h),
    child: Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Items (${_items.length})',
                style: TextStyle(
                    fontSize: 50.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textDark)),
            if (_items.isNotEmpty)
              TextButton.icon(
                onPressed: _clearAll,
                icon: Icon(Icons.delete_outline, size: 50.w),
                label: Text('Clear all', style: TextStyle(fontSize: 40.sp)),
                style: TextButton.styleFrom(foregroundColor: _red),
              ),
          ],
        ),
        10.verticalSpace,
        Container(height: 2.h, width: double.infinity, color: _red),
        20.verticalSpace,
        Expanded(
          child: _items.isEmpty
              ? const EmptyBillState()
              : ListView.separated(
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => 10.verticalSpace,
                  itemBuilder: (_, i) => ProductTile(
                    item: _items[i],
                    onQtyChanged: (q) => _setQty(i, q),
                    onRemove: () => _remove(i),
                  ),
                ),
        ),
      ],
    ),
  );
}

// ---------------- BOTTOM BAR ----------------
Widget _buildBottomBar() {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 100.w),
    child: Column(
      children: [
        20.verticalSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Total Amount',
                    style: TextStyle(fontSize: 50.sp, color: Colors.black)),
                Text('₹ ${_subtotal.toStringAsFixed(0)}',
                    style: TextStyle(
                        fontSize: 60.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.black)),
              ],
            ),
            InkWell(
              onTap: _items.isEmpty
                  ? null
                  : () => _snack('Print bill coming next'), // later: _openPreview
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(27.r),
                  color: _items.isEmpty ? Colors.grey : _red,
                ),
                padding:
                    EdgeInsets.symmetric(vertical: 18.h, horizontal: 150.w),
                child: Text('Continue',
                    style: TextStyle(
                        fontSize: 50.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white)),
              ),
            ),
          ],
        ),
        20.verticalSpace,
      ],
    ),
  );
}
}