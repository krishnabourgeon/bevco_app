import 'package:flutter/material.dart';
import 'package:kiosk/app_colors.dart';


class EmptyBillState extends StatelessWidget {
  const EmptyBillState({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      // Illustration scales with the smaller side so it fits phones in landscape too.
      final d = (c.biggest.shortestSide * 0.45).clamp(120.0, 200.0);
      return Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 360),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: d,
                  height: d,
                  decoration:
                      const BoxDecoration(color: AppColors.primarySoft, shape: BoxShape.circle),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.receipt_long_outlined, size: d * 0.3, color: AppColors.primary),
                      SizedBox(height: d * 0.08),
                      // BarcodeGlyph(width: d * 0.5, height: d * 0.15, color: AppColors.primary),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                const Text('No products yet',
                    style: TextStyle(
                        fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textDark)),
                const SizedBox(height: 8),
                const Text(
                  'Scanned products will appear here\nwith their details and the total amount.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, height: 1.5, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }
}