class Product {
  final String barcode;
  final String name;
  final String category;
  final double price;

  const Product({
    required this.barcode,
    required this.name,
    required this.category,
    required this.price,
  });
}

class CartItem {
  final Product product;
  final int qty;

  const CartItem(this.product, {this.qty = 1});

  double get lineTotal => product.price * qty;
  CartItem copyWith({int? qty}) => CartItem(product, qty: qty ?? this.qty);
}